function BorrarCD(idParametro)
{
	//alert(idParametro);
	
	//	url:"nexo.php",
	//	type:"post",
	alert(idParametro)

}

function EditarCD(idParametro)
{
alert(idParametro)
	Mostrar("MostrarFormAlta");
}

function GuardarCD()
{
	alert("Guardar CD");
	
	
	}