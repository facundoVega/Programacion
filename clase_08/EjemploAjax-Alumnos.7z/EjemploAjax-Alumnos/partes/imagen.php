	<figure class="post-image"> 
				<img src="imagenes/presentacion.jpg" /> 
			</figure>